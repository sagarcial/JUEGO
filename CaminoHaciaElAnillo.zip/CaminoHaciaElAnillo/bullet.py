import pygame
import math
from global_Var import *

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, player_rect):
        super().__init__()
        self.image = pygame.Surface((5, 10))
        self.image.fill(white)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y

        dx = player_rect.centerx - self.rect.centerx
        dy = player_rect.centery - self.rect.centery
        distance = math.hypot(dx, dy)
        if distance > 0:
            self.speed_x = dx / distance * 10  # Ajusta la velocidad según tus necesidades
            self.speed_y = dy / distance * 10  # Ajusta la velocidad según tus necesidades

    def update(self):
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        if self.rect.bottom < 0 or self.rect.top > height or self.rect.left < 0 or self.rect.right > width:
            self.kill()