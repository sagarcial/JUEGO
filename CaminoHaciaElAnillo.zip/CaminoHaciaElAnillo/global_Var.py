width =  800
height = 600
black = (0, 0, 0)
white = (255, 255, 255)